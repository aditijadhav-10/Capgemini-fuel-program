package com.example.EcomEmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
