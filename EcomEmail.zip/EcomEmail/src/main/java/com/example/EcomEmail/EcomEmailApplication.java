package com.example.EcomEmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomEmailApplication.class, args);
	}

}
