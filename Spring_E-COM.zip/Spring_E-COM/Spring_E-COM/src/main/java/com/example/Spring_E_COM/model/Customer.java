package com.example.Spring_E_COM.model;
import jakarta.persistence.*;

@Entity
@Table(name = "customer")
public class Customer extends User{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;

    private String gender;

    private double rating;

    public Customer() {
    }

    public Customer(Long customerId, String gender, double rating) {
        this.customerId = customerId;
        this.gender = gender;
        this.rating = rating;
    }
    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}