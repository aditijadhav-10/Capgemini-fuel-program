package com.example.Spring_E_COM.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Spring_E_COM.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

}