package com.example.Spring6.serviceImpl;

import com.example.Spring6.model.Product;
import com.example.Spring6.repository.ProductRepo;
import com.example.Spring6.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo productRepo;

    @Override
    public Product saveProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public Product getProduct( Long id) {
        return productRepo.findProductById(id).orElseThrow();
    }

    @Override
    public Product updateProduct(Product product,Long id) {
        return null;
    }

    @Override
    public void deleteProduct(Long id) {
        productRepo.deleteById(id);

    }
}
