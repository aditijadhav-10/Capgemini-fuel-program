package com.example.Spring_E_Com.service;

import com.example.Spring_E_Com.dto.product.ProductRequestDTO;
import com.example.Spring_E_Com.dto.product.ProductResponseDTO;

public interface Product_Service {


    ProductResponseDTO saveProduct(ProductRequestDTO productRequestDTO);
}
