package com.example.Spring10.controller;

import com.example.Spring10.model.Employee;
import com.example.Spring10.model.User;
import com.example.Spring10.serviceImpl.EmployeeServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/User")
public class Employeecontroller {
    @Autowired
    private EmployeeServiceImp employeeserviceImp;

    @PostMapping
    public Employee createUser(@RequestBody Employee employee){
        return employeeserviceImp.saveEmployee(employee);
    }

    @GetMapping("/{id}")
    public Employee getdata(@PathVariable Long id)
    {
        return employeeserviceImp.getEmployee(id);
    }

    @DeleteMapping("/{id}")
    public String getdelete(@PathVariable Long id)
    {
        employeeserviceImp.deleteEmployee(id);
        return "The Employee data is Deleted successfully  :"+id;
    }

    @PutMapping("/{id}")
    public Employee getUpdate(@RequestBody Employee employee,@PathVariable Long id)
    {
        employee.setId(id);
        return employeeserviceImp.saveEmployee(employee);
    }
}
